import socket
import sys
import threading
import time
import string
import pickle
#from onlineimage import *


#change addess and port depending on where the server is being run from
host = "192.168.2.199"
port = 9000
message = " "




####CLIENT THREAD FUNCTION####
def clientthread(conn, ip):
    print("Connected to: ", ip)
    while True:
        #Receive the data from the client
        data = conn.recv(1024)
        #Convert bytes to string
        message = data.decode("utf-8")

        #Parse the password and username from a single string
        newdata = message.split() #split string into a list

        #Get the username and password
        command = newdata[0]

        #Determine which command is sent from the Client and execute that command

        #Register command from client
        if command == "register":
            #Save values received into array and to split them up
            username = newdata[1]
            password = newdata[2]
            handle = newdata[3]
            print("from connected user: " + username)
            print("from connected user: " + password)
            print("from connected user: " + handle)
            #call te database function in servermethods to add entries to database
            sendback = True

            #return to the client whether the query failed or went through
            if sendback == False:
                errormessage = "Denied2"
                sendback_byte = errormessage.encode()
                conn.sendall(sendback_byte)
                conn.close()
            if sendback == True:
                errormessage = "Verified"
                sendback_byte = errormessage.encode()
                conn.sendall(sendback_byte)
                conn.close()


        #Login command received from client
        if command == "login":
            username = newdata[1]
            password = newdata[2]

            print("from connected user: " + username)
            print("from connected user: " + password)

            #Call the database function in server methods to check if the password mataches the username registered
            sendback = "Verified"

            #If it doesnt match return denied to client
            if sendback == False:
                errormessage = "Denied2"
                sendback_byte = errormessage.encode()
                conn.sendall(sendback_byte)
                conn.close()


            sendback_byte = sendback.encode()
            conn.sendall(sendback_byte)


        #Close the connection
        conn.close()
        break







#Create a Socket
serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print("Socket Created")

try:
    serversocket.bind((host,port))
except socket.error:
    print("Failed to Bind to Socket")
    sys.exit()

print("Socket has been successfully binded...")

#Listen to incoming connection
serversocket.listen(10)



#Accept Clients
while True:
    conn, addr = serversocket.accept()

    #Start a new thread for each client
    threading._start_new_thread(clientthread, (conn,addr))




