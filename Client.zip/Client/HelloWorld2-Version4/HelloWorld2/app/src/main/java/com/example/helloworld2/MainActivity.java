package com.example.helloworld2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    EditText username_edit, password_edit;
    TextView e1; // e1 is only there to test the output from server
    Button  login;
    private Toast toast;
    Socket client;
    PrintWriter os = null;
    BufferedReader in = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1=(TextView) findViewById(R.id.ViewText2);


        username_edit=(EditText)findViewById(R.id.myusernameOnMain);
        password_edit=(EditText)findViewById(R.id.password);
        login=(Button)findViewById(R.id.loginmine);
        toast = Toast.makeText(this, "Incorrect Credentials", Toast.LENGTH_LONG);


    }

    public void send(View v){
        e1=(TextView) findViewById(R.id.ViewText2);
        e1.setText("touch1");
        username_edit=(EditText)findViewById(R.id.myusernameOnMain);
        password_edit=(EditText)findViewById(R.id.password);

        Runnable runnable = new Runnable() {

            public void run() {
                try {

                    client = new Socket("192.168.2.199", 9000);
                    e1.setText("touch2");

                    //Create Input Stream
                    os = new PrintWriter(client.getOutputStream());
                    in = new BufferedReader(new InputStreamReader(client.getInputStream()));


                    os.write("login");
                    os.write(" ");
                    os.write(username_edit.getText().toString());
                    os.write(" ");
                    os.write(password_edit.getText().toString());
                    os.flush();


                    String received = in.readLine();
                    e1.setText("mssg"+received);

                    if(received.equals("Verified")){
                        Intent mainintent = new Intent(MainActivity.this, Dashboard.class);
                        mainintent.putExtra("username",username_edit.getText().toString() );
                        startActivityForResult(mainintent,100);
                    }
                    if(received.equals("Denied")){
                        toast.show();

                    }
                    if(received.equals("Denied2")){
                        toast.show();
                    }

                    os.close();
                    client.close();

                }catch(Exception e){

                    e.printStackTrace();
                }


            }
        };
        Thread mythread = new Thread(runnable);
        mythread.start();
    }

    public void SignUpNow(View view) {
        Intent intent = new Intent(this,Register.class);
        startActivity(intent);
    }
}