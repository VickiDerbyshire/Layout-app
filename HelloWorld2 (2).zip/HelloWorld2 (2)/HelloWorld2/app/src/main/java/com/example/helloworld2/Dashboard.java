package com.example.helloworld2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Dashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
    }

    public void createLayout(View view) {
    }

    public void selectLayout(View view) {
    }

    public void tableReserv(View view) {
    }

    public void menu(View view) {
        Intent intent = new Intent(this,MenuList.class);
        startActivity(intent);
    }
}